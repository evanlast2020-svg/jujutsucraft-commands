package com.jujutsucommands;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(JujutsuCommands.MOD_ID)
public class JujutsuCommands {
    public static final String MOD_ID = "jujutsucommands";
    private static final Logger LOGGER = LogUtils.getLogger();

    public JujutsuCommands() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(CommandRegistry.class);
        MinecraftForge.EVENT_BUS.register(PlayerJoinHandler.class);
    }
}
