package com.jujutsucommands;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;

public class PlayerJoinHandler {

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        CompoundTag data = player.getPersistentData();

        // Check if already assigned
        if (data.getBoolean("jj_technique_assigned")) return;
        data.putBoolean("jj_technique_assigned", true);

        // Weighted random: C=50%, B=30%, A=15%, S=5%
        double rand = RANDOM.nextDouble() * 100;
        String tier;
        if (rand < 5)       tier = "S";
        else if (rand < 20) tier = "A";
        else if (rand < 50) tier = "B";
        else                tier = "C";

        List<TechniqueData.Technique> pool = TechniqueData.getTier(tier);
        TechniqueData.Technique technique = pool.get(RANDOM.nextInt(pool.size()));

        CommandRegistry.applyTechnique(player, technique);

        String color = CommandRegistry.getTierColor(tier);

        player.sendSystemMessage(Component.literal("§8§l[§6§lJujutsuCraft§8§l] §r§fWelcome, §e" + player.getName().getString() + "§f!"));
        player.sendSystemMessage(Component.literal("§fYour cursed technique has been determined..."));
        player.sendSystemMessage(Component.literal("§8[§6Technique§8] " + color + "[" + tier + "] " + technique.name + "§f!"));
    }
}
