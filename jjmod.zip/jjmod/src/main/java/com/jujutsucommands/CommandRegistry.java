package com.jujutsucommands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

public class CommandRegistry {

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        // /roll <tier> <player>
        event.getDispatcher().register(
            Commands.literal("roll")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("tier", StringArgumentType.word())
                    .suggests(CommandRegistry::suggestTiers)
                    .then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> executeRoll(ctx))
                    )
                )
        );

        // /grant <player> <technique>
        event.getDispatcher().register(
            Commands.literal("grant")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("technique", StringArgumentType.greedyString())
                        .suggests(CommandRegistry::suggestTechniques)
                        .executes(ctx -> executeGrant(ctx))
                    )
                )
        );
    }

    private static CompletableFuture<Suggestions> suggestTiers(CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        builder.suggest("S");
        builder.suggest("A");
        builder.suggest("B");
        builder.suggest("C");
        return builder.buildFuture();
    }

    private static CompletableFuture<Suggestions> suggestTechniques(CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        TechniqueData.ALL.forEach(t -> builder.suggest(t.name.replace(" ", "_")));
        return builder.buildFuture();
    }

    private static int executeRoll(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        String tier = StringArgumentType.getString(ctx, "tier").toUpperCase();
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");

        List<TechniqueData.Technique> pool = TechniqueData.getTier(tier);
        if (pool == null) {
            ctx.getSource().sendFailure(Component.literal("§cInvalid tier! Use S, A, B or C."));
            return 0;
        }

        TechniqueData.Technique technique = pool.get(RANDOM.nextInt(pool.size()));
        applyTechnique(player, technique);

        String color = getTierColor(tier);

        // Broadcast to all players
        ctx.getSource().getServer().getPlayerList().broadcastSystemMessage(
            Component.literal("§8[§6Technique Roll§8] §f" + player.getName().getString() +
                " rolled... " + color + "[" + tier + "] " + technique.name + "§f!"), false
        );

        // Message to player
        player.sendSystemMessage(Component.literal(
            "§8[§6Technique Roll§8] §fYour technique: " + color + "[" + tier + "] " + technique.name + "§f!"
        ));

        ctx.getSource().sendSuccess(() -> Component.literal(
            "§8[§6Technique Roll§8] §fAssigned " + color + "[" + tier + "] " + technique.name + "§f to §e" + player.getName().getString()
        ), false);

        return 1;
    }

    private static int executeGrant(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        String input = StringArgumentType.getString(ctx, "technique").replace("_", " ");

        TechniqueData.Technique technique = TechniqueData.findByName(input);
        if (technique == null) {
            ctx.getSource().sendFailure(Component.literal("§cTechnique \"" + input + "\" not found!"));
            return 0;
        }

        applyTechnique(player, technique);
        String color = getTierColor(technique.tier);

        ctx.getSource().sendSuccess(() -> Component.literal(
            "§8[§6JujutsuCraft§8] §fGranted " + color + "[" + technique.tier + "] " + technique.name + "§f to §e" + player.getName().getString()
        ), false);

        player.sendSystemMessage(Component.literal(
            "§8[§6JujutsuCraft§8] §fYou received: " + color + "[" + technique.tier + "] " + technique.name + "§f!"
        ));

        return 1;
    }

    public static void applyTechnique(ServerPlayer player, TechniqueData.Technique technique) {
        // Get ForgeCaps NBT directly from player
        CompoundTag persistedData = player.getPersistentData();

        // Access ForgeCaps
        CompoundTag forgeCaps;
        if (persistedData.contains("ForgeCaps")) {
            forgeCaps = persistedData.getCompound("ForgeCaps");
        } else {
            forgeCaps = new CompoundTag();
        }

        // Access jujutsucraft:player_variables
        CompoundTag jjVars;
        if (forgeCaps.contains("jujutsucraft:player_variables")) {
            jjVars = forgeCaps.getCompound("jujutsucraft:player_variables");
        } else {
            jjVars = new CompoundTag();
        }

        // Set technique fields
        jjVars.putDouble("PlayerCurseTechnique", technique.id);
        jjVars.putDouble("PlayerCurseTechnique2", technique.id);
        jjVars.putDouble("PlayerSelectCurseTechnique", technique.id);
        jjVars.putString("PlayerSelectCurseTechniqueName", technique.name);
        jjVars.putDouble("PlayerCursePower", technique.cursePower);
        jjVars.putDouble("PlayerCursePowerMAX", technique.cursePowerMax);
        jjVars.putDouble("PlayerCursePowerFormer", technique.cursePowerFormer);
        jjVars.putBoolean("PassiveTechnique", true);

        forgeCaps.put("jujutsucraft:player_variables", jjVars);
        persistedData.put("ForgeCaps", forgeCaps);

        // Force save player data
        player.save(persistedData);
    }

    public static String getTierColor(String tier) {
        return switch (tier) {
            case "S" -> "§c";
            case "A" -> "§6";
            case "B" -> "§e";
            default -> "§f";
        };
    }
}
