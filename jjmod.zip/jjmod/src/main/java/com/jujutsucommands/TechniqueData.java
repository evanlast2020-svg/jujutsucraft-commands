package com.jujutsucommands;

import java.util.ArrayList;
import java.util.List;

public class TechniqueData {

    public static class Technique {
        public final String name;
        public final double id;
        public final String tier;
        public final double cursePower;
        public final double cursePowerMax;
        public final double cursePowerFormer;

        public Technique(String name, double id, String tier, double cursePower) {
            this.name = name;
            this.id = id;
            this.tier = tier;
            this.cursePower = cursePower;
            this.cursePowerMax = cursePower;
            this.cursePowerFormer = cursePower / 4.0;
        }
    }

    public static final List<Technique> S_TIER = new ArrayList<>();
    public static final List<Technique> A_TIER = new ArrayList<>();
    public static final List<Technique> B_TIER = new ArrayList<>();
    public static final List<Technique> C_TIER = new ArrayList<>();
    public static final List<Technique> ALL = new ArrayList<>();

    static {
        // S Tier
        addTechnique("Mahoraga",         16,  "S", 2000);
        addTechnique("Gojo",              2,  "S", 1800);
        addTechnique("Sukuna",            1,  "S", 2000);
        addTechnique("Geto",             18,  "S", 1600);
        addTechnique("Tsukumo",           9,  "S", 1400);
        addTechnique("Yuta",              5,  "S", 1600);
        addTechnique("Maki",             -1,  "S", 1200);
        addTechnique("Hakari",           29,  "S", 1400);
        addTechnique("Megumi",            6,  "S", 1400);
        addTechnique("Yuji",             21,  "S", 1600);
        addTechnique("Kashimo",           7,  "S", 1400);

        // A Tier
        addTechnique("Higuruma",         27,  "A", 1000);
        addTechnique("Yaga",             33,  "A", 1000);
        addTechnique("Yorozu",           39,  "A", 1000);
        addTechnique("Jogo",              4,  "A", 1200);
        addTechnique("Mahito",           15,  "A", 1200);
        addTechnique("Todo",             20,  "A", 1000);
        addTechnique("Angel",            28,  "A", 1000);
        addTechnique("Uraume",           24,  "A", 1000);
        addTechnique("Choso",            10,  "A", 1000);
        addTechnique("Rozetsu",          43,  "A", 1000);

        // B Tier
        addTechnique("Ino",              40,  "B", 800);
        addTechnique("Ogi",              26,  "B", 800);
        addTechnique("Hanami",           14,  "B", 800);
        addTechnique("Dagon",             8,  "B", 800);
        addTechnique("Jinichi",          22,  "B", 800);
        addTechnique("Dhruv Lakdawalla", 37,  "B", 800);
        addTechnique("Nanami",           13,  "B", 800);
        addTechnique("Naoya",            19,  "B", 800);
        addTechnique("Nobara",           34,  "B", 800);
        addTechnique("Miguel",           30,  "B", 800);
        addTechnique("Uro",              38,  "B", 800);
        addTechnique("Reggie",           44,  "B", 800);

        // C Tier
        addTechnique("Inumaki",           3,  "C", 600);
        addTechnique("Mei-Mei",          11,  "C", 600);
        addTechnique("Ishigori",         12,  "C", 600);
        addTechnique("Smallpox",         25,  "C", 600);
        addTechnique("Takaba",           17,  "C", 600);
        addTechnique("Kurourushi",       23,  "C", 600);
        addTechnique("Kusakabe",         31,  "C", 600);
        addTechnique("Chojuro",          32,  "C", 600);
        addTechnique("Nishiyami",        36,  "C", 600);
        addTechnique("Junpei",           35,  "C", 600);
        addTechnique("Kaori",            41,  "C", 600);
        addTechnique("Ranta",            46,  "C", 600);
        addTechnique("Hazenoki",         45,  "C", 600);
    }

    private static void addTechnique(String name, double id, String tier, double power) {
        Technique t = new Technique(name, id, tier, power);
        ALL.add(t);
        switch (tier) {
            case "S" -> S_TIER.add(t);
            case "A" -> A_TIER.add(t);
            case "B" -> B_TIER.add(t);
            case "C" -> C_TIER.add(t);
        }
    }

    public static List<Technique> getTier(String tier) {
        return switch (tier.toUpperCase()) {
            case "S" -> S_TIER;
            case "A" -> A_TIER;
            case "B" -> B_TIER;
            case "C" -> C_TIER;
            default -> null;
        };
    }

    public static Technique findByName(String name) {
        return ALL.stream()
                .filter(t -> t.name.equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }
}
